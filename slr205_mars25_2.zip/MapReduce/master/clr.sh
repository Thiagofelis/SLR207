set -e

cd /cal/homes/tcesar/MesDocuments/SLR205/MapReduce/master/splits
rm -f *
cd /cal/homes/tcesar/MesDocuments/SLR205/MapReduce/master/reduces
rm -f *
