//package DeployPack;
import java.io.*;
import java.util.concurrent.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class RunInSlave extends Thread
{
  int slaveId;
  String[] command;
  String targetMachine;
  AtomicInteger numMachinesFinished;
  public RunInSlave(String tm, String[] cmd, AtomicInteger _numMachinesFinished, int _slaveId)
  {
    slaveId = _slaveId;
    targetMachine = tm;
    command = cmd;
    numMachinesFinished = _numMachinesFinished;
  }
  public void run()
  {
    try {
      ArrayList<String> ssh = new ArrayList<String>(Arrays.asList(new String[]{"ssh", targetMachine}));
      ArrayList<String> cmd = new ArrayList<String>(Arrays.asList(command));

      ssh.addAll(cmd);
      ssh.add("&&"); ssh.add("echo"); ssh.add("ok");

      int j;
      for (j = 0; j < ssh.size(); j++)
      {
        if (ssh.get(j).compareTo("#") == 0)
        {
          ssh.set(j, Integer.toString(slaveId));
        }
      }

      synchronized(numMachinesFinished) {
      ssh.forEach( (entry) -> System.out.print(entry + " ") ); System.out.println(" ");}

      ProcessBuilder pb = new ProcessBuilder(ssh.toArray(new String[0]));
      pb.redirectErrorStream(true);
      Process p = pb.start();
      p.waitFor(25, TimeUnit.SECONDS);

      BufferedReader reader = new BufferedReader (new InputStreamReader (p.getInputStream()));
      if (reader.ready() == false)
      {
        System.out.println(targetMachine + " didnt finish");
        return;
      }
      String outs = reader.readLine();
      if (outs.equals("ok"))
      {
        numMachinesFinished.incrementAndGet();
      }
    } catch (Exception e) {}
  }
}
