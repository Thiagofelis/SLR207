import java.io.*;
import java.util.concurrent.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

class Master {
  public static void main(String[] args)
  {
    int numValidMachines = getValidMachines();

    try {System.in.read();} catch (Exception e) {}

    makeSplits("test", numValidMachines);
    System.out.println("split finished");

    try {System.in.read();} catch (Exception e) {}

    runInSlave(new String[]{"bash", "/cal/homes/tcesar/MesDocuments/SLR205/MapReduce/master/init.sh", "#"});

    try {System.in.read();} catch (Exception e) {}

    runInSlave(new String[]{"java", "-jar", "/tmp/tcesar/Slave.jar", "0", "test"});

    try {System.in.read();} catch (Exception e) {}

    runInSlave(new String[]{"java", "-jar", "/tmp/tcesar/Slave.jar", "1", "test"});

    try {System.in.read();} catch (Exception e) {}

    runInSlave(new String[]{"java", "-jar", "/tmp/tcesar/Slave.jar", "2"});
  }

  static void makeSplits(String fileName, int numSplits)
  {
    try {
      File file = new File(fileName + ".txt");
      InputStream is = new FileInputStream(file);
      FileWriter out = null;

      long avaragePartitionSize = file.length() / numSplits;
      long lastSplit = 0;
      long readerCounter = 0;

      int i;
      int c_in;
      for (i = 0; i < numSplits; i++)
      {
        out = new FileWriter("splits/" + i + ".txt");

        c_in = is.read();
        readerCounter++;
        while (c_in != -1 && ( (readerCounter < avaragePartitionSize + lastSplit) ||
                                (c_in != '\n' && c_in != ' ') ))
        {
          out.write((char) c_in);
          c_in = is.read();
          readerCounter++;
        }
        out.close();
        lastSplit = readerCounter;
      }
      is.close();
    } catch (Exception e) {}
  }

  static void runInSlave(String[] command)
  {
    BufferedReader br = null;
    AtomicInteger numMachinesFinished = new AtomicInteger(0);
    List<RunInSlave> slaves = new ArrayList<RunInSlave>();

    int slaveId = 0;
    String str = null;
    try
    {
      br = new BufferedReader(new FileReader("machines.txt"));
      while ((str = br.readLine()) != null)
      {
        slaves.add(new RunInSlave(str, command, numMachinesFinished, slaveId++));
      }
      br.close();
    } catch (Exception e) {}

    slaves.forEach( (slave) -> slave.start() );
    slaves.forEach( (slave) -> {try {slave.join();} catch (Exception e) {}} );

    System.out.println(numMachinesFinished + " machines finished with ok");
  }

  static int getValidMachines()
  {
    try {
      FileWriter out = new FileWriter("machines.txt");
  		BufferedReader in = new BufferedReader(new FileReader("existing_machines.txt"));
  		List<ConnexionVerifier[]> myList = new ArrayList<ConnexionVerifier[]>();

  		String line = in.readLine();
  		int totalNumMachines = 0;
  		AtomicInteger validMachines = new AtomicInteger(0);
  		while(line != null)
  		{
  			String[] split = line.split(" ");
  			String room = split[0];
  			int numMachines = Integer.parseInt(split[1]);

  			ConnexionVerifier array[] = new ConnexionVerifier[numMachines];

  			int i;
  			for (i = 0; i < numMachines; i++)
  			{
  				totalNumMachines++;
  				if ((i+1) < 10) array[i] = new ConnexionVerifier("tp-" + room + "-0" + (i+1), out, validMachines);
  				else						array[i] = new ConnexionVerifier("tp-" + room + "-" + (i+1), out, validMachines);
  				array[i].start();
  			}
  			myList.add(array);

  			line = in.readLine();
  		}

  		ListIterator<ConnexionVerifier[]> it = myList.listIterator();

  		while(it.hasNext())
  		{
  			int i;
  			ConnexionVerifier array[] = it.next();
  			for (i = 0; i < array.length; i++)
  			{
  				try { array[i].join(); } catch(Exception e) {}
  			}
  		}
  		in.close();
  		out.close();

  		System.out.println(validMachines + " / " + totalNumMachines);

      return validMachines.get();
    } catch (Exception e) {}
    return -1;
  }
}
